/* eslint-disable @typescript-eslint/no-unused-vars */
import Nav from "../components/navbar";

export default function Home() {
  





  return (
    <>

      <Nav />

      <main className="h-[90vh] w-full  flex flex-col justify-center items-center ">
        <section>
          <h1 className="text-red-600 font-bold text-6xl">Bem vindo a biblioteca!</h1>
        </section>
      </main>

    </>

  )
}